
'use client';

import { useState } from 'react';
import { BookingData } from './BookingFlow';

interface UserDetailsProps {
  bookingData: BookingData;
  updateBookingData: (data: Partial<BookingData>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export default function UserDetails({ bookingData, updateBookingData, onNext, onPrev }: UserDetailsProps) {
  const [userDetails, setUserDetails] = useState(bookingData.userDetails);

  const titles = ['Mr.', 'Ms.', 'Mrs.', 'Dr.', 'Prof.'];

  const updateUserDetail = (field: string, value: string) => {
    const updatedDetails = { ...userDetails, [field]: value };
    setUserDetails(updatedDetails);
    updateBookingData({ userDetails: updatedDetails });
  };

  const canProceed = userDetails.title && userDetails.firstName && userDetails.lastName && 
                    userDetails.mobile && userDetails.email;

  return (
    <div className="bg-white rounded-2xl p-8 shadow-lg">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Personal Details</h2>
        <button
          onClick={onPrev}
          className="text-gray-600 hover:text-slate-900 flex items-center cursor-pointer"
        >
          <i className="ri-arrow-left-line mr-2"></i>
          Back
        </button>
      </div>

      <form id="user-details-form" className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
          <div className="grid grid-cols-5 gap-2">
            {titles.map((title) => (
              <button
                key={title}
                type="button"
                onClick={() => updateUserDetail('title', title)}
                className={`px-4 py-2 border-2 rounded-lg text-sm font-medium transition-all cursor-pointer ${ 
                  userDetails.title === title
                    ? 'border-yellow-500 bg-yellow-50 text-yellow-700'
                    : 'border-gray-200 hover:border-yellow-300 text-gray-700'
                }`}
              >
                {title}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">First Name *</label>
            <input
              type="text"
              name="firstName"
              value={userDetails.firstName}
              onChange={(e) => updateUserDetail('firstName', e.target.value)}
              placeholder="Enter your first name"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-500 text-sm"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Last Name *</label>
            <input
              type="text"
              name="lastName"
              value={userDetails.lastName}
              onChange={(e) => updateUserDetail('lastName', e.target.value)}
              placeholder="Enter your last name"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-500 text-sm"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Mobile Number *</label>
          <input
            type="tel"
            name="mobile"
            value={userDetails.mobile}
            onChange={(e) => updateUserDetail('mobile', e.target.value)}
            placeholder="+91 XXXXX XXXXX"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-500 text-sm"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
          <input
            type="email"
            name="email"
            value={userDetails.email}
            onChange={(e) => updateUserDetail('email', e.target.value)}
            placeholder="your.email@example.com"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-500 text-sm"
            required
          />
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-start">
            <i className="ri-information-line text-yellow-600 mr-3 mt-0.5"></i>
            <div className="text-sm text-yellow-800">
              <p className="font-medium mb-1">Important Notice:</p>
              <p>Please ensure all details are accurate. Our representative will contact you on the provided mobile number for coordination.</p>
            </div>
          </div>
        </div>

        {canProceed && (
          <div className="flex justify-end pt-4">
            <button
              type="button"
              onClick={onNext}
              className="bg-yellow-500 hover:bg-yellow-600 text-black px-8 py-3 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap"
            >
              Continue to Payment
            </button>
          </div>
        )}
      </form>
    </div>
  );
}
