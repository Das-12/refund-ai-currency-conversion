
'use client';

export default function AirportsSection() {
  const airports = [
    {
      name: 'Cochin International Airport',
      code: 'COK',
      city: 'Kochi',
      image: 'https://readdy.ai/api/search-image?query=cochin%20international%20airport%20terminal%20building%20with%20kerala%20architecture%2C%20modern%20glass%20structure%2C%20coconut%20trees%2C%20clean%20professional%20environment%2C%20travelers%20with%20luggage%2C%20bright%20natural%20lighting%2C%20contemporary%20design%20with%20traditional%20elements&width=600&height=400&seq=airport-cok&orientation=landscape',
      terminals: 'All Terminals',
      features: ['International Hub', 'Solar Powered', '24/7 Operations']
    },
    {
      name: 'Chennai International Airport',
      code: 'MAA',
      city: 'Chennai',
      image: 'https://readdy.ai/api/search-image?query=chennai%20international%20airport%20modern%20terminal%20with%20south%20indian%20architectural%20elements%2C%20glass%20facade%2C%20palm%20trees%2C%20professional%20airport%20environment%2C%20clean%20contemporary%20design%2C%20travelers%20and%20staff%2C%20bright%20lighting&width=600&height=400&seq=airport-maa&orientation=landscape',
      terminals: 'All Terminals',
      features: ['Major Gateway', 'Modern Facilities', 'Premium Lounges']
    },
    {
      name: 'Calicut International Airport',
      code: 'CCJ',
      city: 'Kozhikode',
      image: 'https://readdy.ai/api/search-image?query=calicut%20kozhikode%20airport%20terminal%20building%20with%20kerala%20traditional%20architecture%20mixed%20with%20modern%20elements%2C%20tropical%20landscaping%2C%20coconut%20palms%2C%20clean%20airport%20environment%2C%20professional%20setting%2C%20natural%20lighting&width=600&height=400&seq=airport-ccj&orientation=landscape',
      terminals: 'All Terminals',
      features: ['Regional Hub', 'Cargo Facilities', 'Gulf Connections']
    },
    {
      name: 'Kannur International Airport',
      code: 'CNN',
      city: 'Kannur',
      image: 'https://readdy.ai/api/search-image?query=kannur%20international%20airport%20modern%20terminal%20with%20kerala%20architectural%20influences%2C%20lush%20green%20surroundings%2C%20contemporary%20glass%20design%2C%20tropical%20vegetation%2C%20professional%20airport%20setting%2C%20clean%20bright%20environment&width=600&height=400&seq=airport-cnn&orientation=landscape',
      terminals: 'All Terminals',
      features: ['Newest Airport', 'Green Technology', 'International Flights']
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            Our Service Locations
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Available at all major airports across Kerala and Chennai
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {airports.map((airport, index) => (
            <div key={index} className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
              <div className="relative h-64">
                <img 
                  src={airport.image}
                  alt={airport.name}
                  className="w-full h-full object-cover object-top"
                />
                <div className="absolute top-4 right-4 bg-yellow-500 text-black px-4 py-2 rounded-full font-bold text-lg">
                  {airport.code}
                </div>
              </div>
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-800 mb-2">
                  {airport.name}
                </h3>
                <p className="text-gray-600 mb-4 flex items-center">
                  <i className="ri-map-pin-line mr-2"></i>
                  {airport.city}
                </p>
                <div className="mb-6">
                  <div className="flex items-center mb-3">
                    <i className="ri-building-line text-yellow-600 mr-2"></i>
                    <span className="font-semibold text-gray-800">{airport.terminals}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {airport.features.map((feature, idx) => (
                      <span key={idx} className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="border-t pt-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-green-600">
                      <i className="ri-check-circle-fill mr-2"></i>
                      <span className="font-semibold">Service Available</span>
                    </div>
                    <button className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-2 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap">
                      Book Now
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-r from-slate-900 to-slate-800 rounded-3xl p-8 md:p-12 text-white text-center">
          <h3 className="text-3xl md:text-4xl font-bold mb-6 text-yellow-400">Serving All Terminals</h3>
          <p className="text-xl mb-8 opacity-90">Our dedicated team is available at every terminal of these airports, ensuring seamless service regardless of your departure or arrival point.</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="bg-yellow-400/20 backdrop-blur-sm rounded-xl p-4 border border-yellow-400/30">
              <i className="ri-time-line text-3xl mb-2 text-yellow-400"></i>
              <div className="font-semibold">24/7 Service</div>
            </div>
            <div className="bg-yellow-400/20 backdrop-blur-sm rounded-xl p-4 border border-yellow-400/30">
              <i className="ri-user-star-line text-3xl mb-2 text-yellow-400"></i>
              <div className="font-semibold">VIP Treatment</div>
            </div>
            <div className="bg-yellow-400/20 backdrop-blur-sm rounded-xl p-4 border border-yellow-400/30">
              <i className="ri-shield-check-line text-3xl mb-2 text-yellow-400"></i>
              <div className="font-semibold">Safe & Secure</div>
            </div>
            <div className="bg-yellow-400/20 backdrop-blur-sm rounded-xl p-4 border border-yellow-400/30">
              <i className="ri-heart-line text-3xl mb-2 text-yellow-400"></i>
              <div className="font-semibold">With Care</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
