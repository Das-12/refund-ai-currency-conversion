
'use client';

import { BookingData } from './BookingFlow';

interface AirportSelectionProps {
  bookingData: BookingData;
  updateBookingData: (data: Partial<BookingData>) => void;
  onNext: () => void;
}

export default function AirportSelection({ bookingData, updateBookingData, onNext }: AirportSelectionProps) {
  const airports = [
    { code: 'COK', name: 'Cochin International Airport', city: 'Kochi' },
    { code: 'MAA', name: 'Chennai International Airport', city: 'Chennai' },
    { code: 'CCJ', name: 'Calicut International Airport', city: 'Kozhikode' },
    { code: 'CNN', name: 'Kannur International Airport', city: 'Kannur' }
  ];

  const handleAirportSelect = (airport: { code: string; name: string; city: string }) => {
    updateBookingData({
      airport: airport.code,
      airportName: airport.name
    });
  };

  const handleServiceTypeSelect = (type: 'departure' | 'arrival') => {
    updateBookingData({ serviceType: type });
  };

  return (
    <div className="bg-white rounded-2xl p-8 shadow-lg mb-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-6">Select Airport</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {airports.map((airport) => (
          <div
            key={airport.code}
            onClick={() => handleAirportSelect(airport)}
            className={`p-6 border-2 rounded-xl cursor-pointer transition-all ${
              bookingData.airport === airport.code
                ? 'border-yellow-500 bg-yellow-50'
                : 'border-gray-200 hover:border-yellow-300'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-lg text-slate-900">{airport.code}</h3>
              <i className={`ri-checkbox-circle-${bookingData.airport === airport.code ? 'fill text-yellow-500' : 'line text-gray-400'}`}></i>
            </div>
            <p className="text-slate-700 font-medium">{airport.name}</p>
            <p className="text-gray-600 text-sm">{airport.city}</p>
          </div>
        ))}
      </div>

      {bookingData.airport && (
        <div>
          <h3 className="text-xl font-bold text-slate-900 mb-4">Service Type</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div
              onClick={() => handleServiceTypeSelect('departure')}
              className={`p-6 border-2 rounded-xl cursor-pointer transition-all ${
                bookingData.serviceType === 'departure'
                  ? 'border-yellow-500 bg-yellow-50'
                  : 'border-gray-200 hover:border-yellow-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <i className="ri-takeoff-line text-2xl text-blue-600"></i>
                </div>
                <i className={`ri-checkbox-circle-${bookingData.serviceType === 'departure' ? 'fill text-yellow-500' : 'line text-gray-400'}`}></i>
              </div>
              <h4 className="font-bold text-lg text-slate-900">Departure</h4>
              <p className="text-gray-600">Assistance for outbound flights</p>
            </div>

            <div
              onClick={() => handleServiceTypeSelect('arrival')}
              className={`p-6 border-2 rounded-xl cursor-pointer transition-all ${
                bookingData.serviceType === 'arrival'
                  ? 'border-yellow-500 bg-yellow-50'
                  : 'border-gray-200 hover:border-yellow-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <i className="ri-flight-land-line text-2xl text-green-600"></i>
                </div>
                <i className={`ri-checkbox-circle-${bookingData.serviceType === 'arrival' ? 'fill text-yellow-500' : 'line text-gray-400'}`}></i>
              </div>
              <h4 className="font-bold text-lg text-slate-900">Arrival</h4>
              <p className="text-gray-600">Assistance for inbound flights</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
