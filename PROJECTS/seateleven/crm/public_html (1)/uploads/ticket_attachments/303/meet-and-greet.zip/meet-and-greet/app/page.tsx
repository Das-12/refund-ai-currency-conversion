'use client';

import Link from 'next/link';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import ServicesSection from './components/ServicesSection';
import AirportsSection from './components/AirportsSection';
import AboutSection from './components/AboutSection';
import ContactSection from './components/ContactSection';

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      <HeroSection />
      <ServicesSection />
      <AirportsSection />
      <AboutSection />
      <ContactSection />
    </div>
  );
}