
'use client';

import { BookingData } from './BookingFlow';

interface ServiceSelectionProps {
  bookingData: BookingData;
  updateBookingData: (data: Partial<BookingData>) => void;
  onNext: () => void;
}

export default function ServiceSelection({ bookingData, updateBookingData, onNext }: ServiceSelectionProps) {
  const services = [
    {
      id: 'basic',
      name: 'Basic Meet & Greet',
      price: 2500,
      features: [
        'Meet at designated point',
        'Basic assistance',
        'Gate escort'
      ]
    },
    {
      id: 'premium',
      name: 'Premium Service',
      price: 4500,
      features: [
        'Curbside meet & greet',
        'Baggage handling',
        'Priority check-in',
        'Security escort'
      ]
    },
    {
      id: 'elite',
      name: 'FlyLux Elite',
      price: 7500,
      features: [
        'Personalized curbside meet',
        'Full baggage assistance',
        'Fast-track support',
        'Security & immigration escort',
        'Priority check-in guidance',
        'Gate escort until boarding'
      ]
    }
  ];

  const terminals = ['Terminal 1', 'Terminal 2', 'Terminal 3', 'International Terminal'];

  const handleServiceSelect = (service: any) => {
    updateBookingData({
      service: service.id,
      serviceName: service.name,
      servicePrice: service.price
    });
  };

  const handleTerminalSelect = (terminal: string) => {
    updateBookingData({ terminal });
  };

  const canProceed = bookingData.airport && bookingData.serviceType && bookingData.terminal && bookingData.service;

  return (
    <>
      {bookingData.serviceType && (
        <div className="bg-white rounded-2xl p-8 shadow-lg mb-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Select Terminal</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
            {terminals.map((terminal) => (
              <div
                key={terminal}
                onClick={() => handleTerminalSelect(terminal)}
                className={`p-4 border-2 rounded-lg cursor-pointer text-center transition-all ${
                  bookingData.terminal === terminal
                    ? 'border-yellow-500 bg-yellow-50 text-yellow-700'
                    : 'border-gray-200 hover:border-yellow-300 text-gray-700'
                }`}
              >
                <i className="ri-building-line text-xl mb-2"></i>
                <div className="font-medium text-sm">{terminal}</div>
              </div>
            ))}
          </div>

          {bookingData.terminal && (
            <div>
              <h3 className="text-xl font-bold text-slate-900 mb-4">Choose Your Service</h3>
              <div className="space-y-4">
                {services.map((service) => (
                  <div
                    key={service.id}
                    onClick={() => handleServiceSelect(service)}
                    className={`p-6 border-2 rounded-xl cursor-pointer transition-all ${
                      bookingData.service === service.id
                        ? 'border-yellow-500 bg-yellow-50'
                        : 'border-gray-200 hover:border-yellow-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="font-bold text-lg text-slate-900">{service.name}</h3>
                        <p className="text-2xl font-bold text-yellow-600">₹{service.price.toLocaleString()}</p>
                      </div>
                      <i className={`ri-checkbox-circle-${bookingData.service === service.id ? 'fill text-yellow-500' : 'line text-gray-400'}`}></i>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {service.features.map((feature, index) => (
                        <div key={index} className="flex items-center text-sm text-gray-700">
                          <i className="ri-check-line text-green-500 mr-2"></i>
                          {feature}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {canProceed && (
            <div className="mt-8 flex justify-end">
              <button
                onClick={onNext}
                className="bg-yellow-500 hover:bg-yellow-600 text-black px-8 py-3 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap"
              >
                Continue to Flight Details
              </button>
            </div>
          )}
        </div>
      )}
    </>
  );
}
