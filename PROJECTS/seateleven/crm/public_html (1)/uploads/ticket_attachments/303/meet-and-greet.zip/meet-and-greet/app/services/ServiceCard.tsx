'use client';

import Link from 'next/link';
import { Service } from './page';

interface ServiceCardProps {
  service: Service;
}

export default function ServiceCard({ service }: ServiceCardProps) {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'basic':
        return 'bg-blue-100 text-blue-700';
      case 'premium':
        return 'bg-purple-100 text-purple-700';
      case 'elite':
        return 'bg-yellow-100 text-yellow-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getTypeIcon = (type: string) => {
    return type === 'departure' ? 'ri-takeoff-line' : 'ri-flight-land-line';
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
      <div className="relative">
        <img 
          src={service.image} 
          alt={service.name}
          className="w-full h-48 object-cover object-top"
        />
        <div className="absolute top-4 left-4">
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getCategoryColor(service.category)}`}>
            {service.category.charAt(0).toUpperCase() + service.category.slice(1)}
          </span>
        </div>
        <div className="absolute top-4 right-4">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
            service.type === 'departure' ? 'bg-blue-500' : 'bg-green-500'
          }`}>
            <i className={`${getTypeIcon(service.type)} text-white text-lg`}></i>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xl font-bold text-slate-900">{service.name}</h3>
          <div className="text-right">
            <div className="text-2xl font-bold text-yellow-600">₹{service.price.toLocaleString()}</div>
            <div className="text-sm text-gray-500">{service.duration}</div>
          </div>
        </div>

        <div className="flex items-center mb-3">
          <div className="flex items-center">
            <i className="ri-star-fill text-yellow-400 text-sm"></i>
            <span className="ml-1 text-sm font-medium text-gray-700">{service.rating}</span>
            <span className="ml-1 text-sm text-gray-500">({service.reviews} reviews)</span>
          </div>
        </div>

        <div className="mb-4">
          <div className="flex items-center text-sm text-gray-600 mb-1">
            <i className="ri-map-pin-line mr-2"></i>
            {service.airportName}
          </div>
          <div className="flex items-center text-sm text-gray-600">
            <i className="ri-building-line mr-2"></i>
            {service.terminal}
          </div>
        </div>

        <p className="text-gray-600 text-sm mb-4">{service.description}</p>

        <div className="space-y-2 mb-6">
          {service.features.slice(0, 3).map((feature, index) => (
            <div key={index} className="flex items-center text-sm text-gray-700">
              <i className="ri-check-line text-green-500 mr-2"></i>
              {feature}
            </div>
          ))}
          {service.features.length > 3 && (
            <div className="text-sm text-gray-500">
              +{service.features.length - 3} more features
            </div>
          )}
        </div>

        <div className="flex items-center space-x-3">
          <Link
            href={`/booking?service=${service.id}`}
            className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-black px-4 py-2 rounded-lg font-semibold text-center transition-colors cursor-pointer whitespace-nowrap"
          >
            Book Now
          </Link>
          <button className="w-10 h-10 border border-gray-300 rounded-lg flex items-center justify-center hover:bg-gray-50 transition-colors cursor-pointer">
            <i className="ri-heart-line text-gray-600"></i>
          </button>
        </div>
      </div>
    </div>
  );
}