
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { BookingData } from './BookingFlow';

interface PaymentSectionProps {
  bookingData: BookingData;
  updateBookingData: (data: Partial<BookingData>) => void;
  onPrev: () => void;
}

export default function PaymentSection({ bookingData, updateBookingData, onPrev }: PaymentSectionProps) {
  const router = useRouter();
  const [selectedPaymentMode, setSelectedPaymentMode] = useState(bookingData.paymentMode || 'razorpay');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [cardDetails, setCardDetails] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardholderName: ''
  });

  const paymentModes = [
    {
      id: 'razorpay',
      name: 'Razorpay',
      icon: 'ri-secure-payment-line',
      description: 'Cards, UPI, Net Banking & More'
    }
  ];

  const taxAmount = Math.round(bookingData.servicePrice * 0.18);
  const totalAmount = bookingData.servicePrice + taxAmount;

  const handlePaymentModeSelect = (mode: string) => {
    setSelectedPaymentMode(mode);
    updateBookingData({ paymentMode: mode });
  };

  const handlePayment = async () => {
    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      // Redirect to payment success page
      router.push('/booking/success');
    }, 2000);
  };

  if (paymentSuccess) {
    return (
      <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <i className="ri-check-line text-4xl text-green-600"></i>
        </div>
        <h2 className="text-3xl font-bold text-slate-900 mb-4">Payment Successful!</h2>
        <p className="text-gray-600 mb-6">Your booking has been confirmed. You will receive a confirmation email shortly.</p>

        <div className="bg-gray-50 rounded-lg p-6 mb-6">
          <div className="text-left">
            <h3 className="font-bold text-lg text-slate-900 mb-4">Booking Details</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Booking ID:</span>
                <span className="font-medium">FL{Date.now().toString().slice(-6)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Amount Paid:</span>
                <span className="font-medium">₹{totalAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Payment Mode:</span>
                <span className="font-medium capitalize">{selectedPaymentMode}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
          <div className="flex items-start text-left">
            <i className="ri-information-line text-yellow-600 mr-3 mt-0.5"></i>
            <div className="text-sm text-yellow-800">
              <p className="font-medium mb-1">What's Next?</p>
              <p>Our representative will contact you 2 hours before your flight time to coordinate the meet-up location.</p>
            </div>
          </div>
        </div>

        <button
          onClick={() => window.location.href = '/'}
          className="bg-yellow-500 hover:bg-yellow-600 text-black px-8 py-3 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap"
        >
          Back to Home
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl p-8 shadow-lg">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Payment</h2>
        <button
          onClick={onPrev}
          className="text-gray-600 hover:text-slate-900 flex items-center cursor-pointer"
        >
          <i className="ri-arrow-left-line mr-2"></i>
          Back
        </button>
      </div>

      <div className="mb-8">
        <h3 className="text-xl font-bold text-slate-900 mb-4">Select Payment Method</h3>
        <div className="grid grid-cols-1 gap-4">
          {paymentModes.map((mode) => (
            <div
              key={mode.id}
              onClick={() => handlePaymentModeSelect(mode.id)}
              className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                selectedPaymentMode === mode.id
                  ? 'border-yellow-500 bg-yellow-50'
                  : 'border-gray-200 hover:border-yellow-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                    <i className={`${mode.icon} text-xl text-gray-600`}></i>
                  </div>
                  <div>
                    <div className="font-medium text-slate-900">{mode.name}</div>
                    <div className="text-sm text-gray-600">{mode.description}</div>
                  </div>
                </div>
                <i className={`ri-checkbox-circle-${selectedPaymentMode === mode.id ? 'fill text-yellow-500' : 'line text-gray-400'}`}></i>
              </div>
            </div>
          ))}
        </div>
      </div>

      {selectedPaymentMode && (
        <div className="border-t pt-6">
          <div className="bg-slate-900 text-white rounded-lg p-6 mb-6">
            <h4 className="font-bold text-lg mb-4">Payment Summary</h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Service Amount</span>
                <span>₹{bookingData.servicePrice.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Tax (18%)</span>
                <span>₹{taxAmount.toLocaleString()}</span>
              </div>
              <div className="border-t border-gray-600 pt-2">
                <div className="flex justify-between font-bold text-xl">
                  <span>Total Amount</span>
                  <span className="text-yellow-400">₹{totalAmount.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={handlePayment}
            disabled={isProcessing}
            className={`w-full py-4 rounded-full font-bold text-lg transition-colors cursor-pointer whitespace-nowrap ${
              isProcessing
                ? 'bg-gray-400 text-gray-700 cursor-not-allowed'
                : 'bg-yellow-500 hover:bg-yellow-600 text-black'
            }`}
          >
            {isProcessing ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-gray-700 mr-3"></div>
                Processing Payment...
              </div>
            ) : (
              `Pay ₹${totalAmount.toLocaleString()}`
            )}
          </button>

          <div className="mt-4 text-center">
            <div className="flex items-center justify-center text-sm text-gray-600">
              <i className="ri-shield-check-line mr-2"></i>
              Your payment is secured with 256-bit SSL encryption
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
