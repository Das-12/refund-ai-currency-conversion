'use client';

export default function AboutSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-8">
              Experience Kerala's Hospitality at Every Step
            </h2>
            
            <div className="space-y-6 mb-8">
              <p className="text-lg text-gray-600 leading-relaxed">
                At FeelSafe Elite, we blend Kerala's renowned hospitality with professional airport services. Our mission is to transform your travel experience from stressful to seamless, ensuring every moment of your journey is comfortable and worry-free.
              </p>
              
              <p className="text-lg text-gray-600 leading-relaxed">
                From the moment you step out of your vehicle to the time you board your flight, our dedicated concierge team provides personalized attention that reflects the warmth and care Kerala is famous for.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-yellow-50 rounded-xl p-6 border-l-4 border-yellow-500">
                <h4 className="font-bold text-gray-800 mb-2">Traditional Values</h4>
                <p className="text-gray-600">Rooted in Kerala's culture of respect, care, and genuine hospitality</p>
              </div>
              <div className="bg-green-50 rounded-xl p-6 border-l-4 border-green-500">
                <h4 className="font-bold text-gray-800 mb-2">Modern Efficiency</h4>
                <p className="text-gray-600">Cutting-edge processes designed for today's busy travelers</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-yellow-500 hover:bg-yellow-600 text-black px-8 py-4 rounded-full text-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
                Learn More About Us
              </button>
              <button className="border-2 border-gray-300 hover:border-gray-400 text-gray-700 hover:bg-gray-50 px-8 py-4 rounded-full text-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
                View Testimonials
              </button>
            </div>
          </div>

          <div className="relative">
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=kerala%20traditional%20hospitality%20scene%20at%20modern%20airport%2C%20staff%20in%20traditional%20white%20kerala%20attire%20helping%20travelers%2C%20coconut%20trees%2C%20warm%20golden%20lighting%2C%20professional%20service%20with%20cultural%20touch%2C%20airport%20terminal%20with%20kerala%20architectural%20elements%2C%20peaceful%20atmosphere&width=700&height=500&seq=kerala-hospitality&orientation=landscape"
                alt="Kerala Hospitality"
                className="rounded-3xl shadow-2xl object-cover w-full h-96"
              />
              
              <div className="absolute -bottom-6 -right-6 bg-white rounded-2xl p-6 shadow-xl">
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-600 mb-1">1000+</div>
                  <div className="text-gray-600 text-sm">Happy Travelers</div>
                </div>
              </div>
              
              <div className="absolute -top-6 -left-6 bg-green-500 rounded-2xl p-6 shadow-xl text-white">
                <div className="text-center">
                  <div className="text-3xl font-bold mb-1">5★</div>
                  <div className="text-green-100 text-sm">Rating</div>
                </div>
              </div>
            </div>

            <div className="mt-12 grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="ri-user-heart-line text-2xl text-yellow-600"></i>
                </div>
                <h5 className="font-semibold text-gray-800">Personal Care</h5>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="ri-time-line text-2xl text-green-600"></i>
                </div>
                <h5 className="font-semibold text-gray-800">Time Saving</h5>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="ri-shield-star-line text-2xl text-blue-600"></i>
                </div>
                <h5 className="font-semibold text-gray-800">Peace of Mind</h5>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}