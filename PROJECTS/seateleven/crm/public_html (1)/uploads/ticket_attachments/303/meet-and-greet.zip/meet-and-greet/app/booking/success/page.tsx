
'use client';

import Link from 'next/link';
import { useRef } from 'react';

export default function PaymentSuccessPage() {
  const voucherRef = useRef<HTMLDivElement>(null);
  const bookingId = `FL${Date.now().toString().slice(-6)}`;
  const bookingDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  const bookingTime = new Date().toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit'
  });

  const downloadVoucher = () => {
    if (voucherRef.current) {
      const printWindow = window.open('', '', 'width=800,height=600');
      if (printWindow) {
        const voucherContent = voucherRef.current.innerHTML;
        printWindow.document.write(`
          <html>
            <head>
              <title>Booking Voucher - ${bookingId}</title>
              <style>
                body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
                .voucher { max-width: 800px; margin: 0 auto; }
                .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #000; padding-bottom: 20px; }
                .section { margin-bottom: 25px; }
                .section h3 { color: #333; font-size: 18px; margin-bottom: 10px; border-bottom: 1px solid #ccc; padding-bottom: 5px; }
                .details { display: flex; justify-content: space-between; margin-bottom: 8px; }
                .details span:first-child { font-weight: bold; }
                .qr-section { text-align: center; margin: 20px 0; }
                .rules { font-size: 12px; }
                .rules ul { margin: 5px 0; padding-left: 20px; }
                .rules li { margin-bottom: 3px; }
                .total { font-weight: bold; font-size: 16px; border-top: 2px solid #000; padding-top: 10px; }
                @media print { body { margin: 0; } }
              </style>
            </head>
            <body>
              <div class="voucher">
                ${voucherContent}
              </div>
              <script>
                window.onload = function() {
                  window.print();
                  window.close();
                }
              </script>
            </body>
          </html>
        `);
        printWindow.document.close();
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-6">
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-check-line text-4xl text-green-600"></i>
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-4">Payment Successful!</h1>
            <p className="text-gray-600 mb-2">Your booking has been confirmed. You will receive a confirmation email shortly.</p>
            <p className="text-sm text-gray-500">Booking ID: <span className="font-medium text-gray-900">{bookingId}</span></p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Service Details */}
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="font-bold text-lg text-slate-900 mb-4 flex items-center">
                <i className="ri-service-line mr-2"></i>
                Service Details
              </h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Service Type:</span>
                  <span className="font-medium">Departure Assistance</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Service Package:</span>
                  <span className="font-medium">Basic Meet & Greet</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Airport:</span>
                  <span className="font-medium">COK - Cochin International Airport</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Terminal:</span>
                  <span className="font-medium">Terminal 1</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Flight:</span>
                  <span className="font-medium">AI 681 - Delhi</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Flight Time:</span>
                  <span className="font-medium">08:30 AM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Service Date:</span>
                  <span className="font-medium">{new Date(Date.now() + 86400000).toLocaleDateString('en-US', { 
                    weekday: 'short',
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric'
                  })}</span>
                </div>
              </div>
            </div>

            {/* Customer Information */}
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="font-bold text-lg text-slate-900 mb-4 flex items-center">
                <i className="ri-user-line mr-2"></i>
                Customer Information
              </h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Name:</span>
                  <span className="font-medium">Mr. Rajesh Kumar</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Mobile:</span>
                  <span className="font-medium">+91 98765 43210</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Email:</span>
                  <span className="font-medium">rajesh.kumar@email.com</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Booking Date:</span>
                  <span className="font-medium">{bookingDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Booking Time:</span>
                  <span className="font-medium">{bookingTime}</span>
                </div>
              </div>
            </div>

            {/* Payment Information */}
            <div className="bg-slate-900 text-white rounded-lg p-6">
              <h3 className="font-bold text-lg mb-4 flex items-center">
                <i className="ri-credit-card-line mr-2"></i>
                Payment Information
              </h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-300">Service Amount:</span>
                  <span className="font-medium">₹2,500</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Tax (18%):</span>
                  <span className="font-medium">₹450</span>
                </div>
                <div className="border-t border-gray-600 pt-3">
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total Amount:</span>
                    <span className="text-yellow-400">₹2,950</span>
                  </div>
                </div>
                <div className="mt-4 pt-3 border-t border-gray-600">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Payment Method:</span>
                    <span className="font-medium">Razorpay</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Transaction ID:</span>
                    <span className="font-medium">TXN{Date.now().toString().slice(-8)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Payment Status:</span>
                    <span className="font-medium text-green-400">Successful</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Payment Time:</span>
                    <span className="font-medium">{bookingTime}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* QR Code Section */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h3 className="font-bold text-lg text-slate-900 mb-4 flex items-center">
                <i className="ri-qr-code-line mr-2"></i>
                Booking QR Code
              </h3>
              <div className="text-center">
                <div className="inline-block bg-white p-4 rounded-lg border-2 border-blue-200">
                  <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${bookingId}&bgcolor=ffffff&color=000000`}
                    alt="Booking QR Code" 
                    className="w-30 h-30"
                  />
                </div>
                <p className="text-sm text-blue-700 mt-2">Scan for booking details</p>
                <p className="text-xs text-blue-600 font-medium">{bookingId}</p>
              </div>
            </div>

            {/* Service Features */}
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
              <h3 className="font-bold text-lg text-slate-900 mb-4 flex items-center">
                <i className="ri-star-line mr-2"></i>
                Included Services
              </h3>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-700">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Meet at designated point
                </div>
                <div className="flex items-center text-sm text-gray-700">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Basic assistance with directions
                </div>
                <div className="flex items-center text-sm text-gray-700">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Gate escort service
                </div>
                <div className="flex items-center text-sm text-gray-700">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Real-time coordination
                </div>
              </div>
            </div>
          </div>

          {/* Important Information */}
          <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <div className="flex items-start">
              <i className="ri-information-line text-blue-600 mr-3 mt-0.5"></i>
              <div className="text-sm text-blue-800">
                <p className="font-medium mb-2">Important Instructions:</p>
                <ul className="space-y-1 list-disc list-inside">
                  <li>Our representative will contact you 2 hours before your flight time</li>
                  <li>Please keep your mobile phone accessible for coordination</li>
                  <li>Arrive at the airport at least 2 hours before domestic flights</li>
                  <li>Carry valid ID proof and flight tickets</li>
                  <li>For any changes or cancellations, contact us at least 4 hours before service time</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-8">
            <div className="flex items-start">
              <i className="ri-information-line text-yellow-600 mr-3 mt-1 flex-shrink-0"></i>
              <div className="text-sm text-yellow-800">
                <p className="font-medium mb-2">What's Next?</p>
                <ul className="space-y-1 text-sm">
                  <li>• Our representative will contact you 2 hours before your flight time</li>
                  <li>• Please arrive at the designated meeting point on time</li>
                  <li>• Keep your booking confirmation and ID ready</li>
                  <li>• For any changes, contact us at least 4 hours in advance</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-white border border-gray-200 rounded-lg p-6 mb-8">
            <h3 className="text-xl font-bold text-slate-900 mb-4 flex items-center">
              <i className="ri-customer-service-2-line mr-2"></i>
              Need Help?
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <h4 className="font-semibold text-slate-900 mb-2">24/7 Customer Support</h4>
                <p className="text-sm text-gray-700 mb-2">Call us anytime for assistance</p>
                <p className="text-blue-600 font-medium">+91 95000 12345</p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <h4 className="font-semibold text-slate-900 mb-2">Email Support</h4>
                <p className="text-sm text-gray-700 mb-2">For detailed queries</p>
                <p className="text-green-600 font-medium">support@example.com</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={downloadVoucher}
              className="flex items-center justify-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap"
            >
              <i className="ri-download-line mr-2"></i>
              Download Voucher
            </button>
            <button
              onClick={() => window.print()}
              className="flex items-center justify-center px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors whitespace-nowrap"
            >
              <i className="ri-printer-line mr-2"></i>
              Print Receipt
            </button>
            <Link href="/" className="flex items-center justify-center px-6 py-3 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors whitespace-nowrap">
              <i className="ri-home-line mr-2"></i>
              Back to Home
            </Link>
            <Link href="/booking" className="flex items-center justify-center px-6 py-3 bg-yellow-500 text-black rounded-lg hover:bg-yellow-600 transition-colors whitespace-nowrap">
              <i className="ri-add-line mr-2"></i>
              Book Another Service
            </Link>
          </div>
        </div>

        {/* Hidden Voucher Content for Download */}
        <div ref={voucherRef} style={{ display: 'none' }}>
          <div className="header">
            <h1 style={{ margin: '0 0 10px 0', fontSize: '24px' }}>BOOKING VOUCHER</h1>
            <p style={{ margin: '0', fontSize: '14px', color: '#666' }}>Airport Assistance Services</p>
          </div>

          <div className="section">
            <h3>Service Details</h3>
            <div className="details"><span>Service Type:</span><span>Departure Assistance</span></div>
            <div className="details"><span>Service Package:</span><span>Basic Meet & Greet</span></div>
            <div className="details"><span>Airport:</span><span>COK - Cochin International Airport</span></div>
            <div className="details"><span>Terminal:</span><span>Terminal 1</span></div>
            <div className="details"><span>Flight:</span><span>AI 681 - Delhi</span></div>
            <div className="details"><span>Flight Time:</span><span>08:30 AM</span></div>
            <div className="details"><span>Service Date:</span><span>{new Date(Date.now() + 86400000).toLocaleDateString('en-US', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' })}</span></div>
          </div>

          <div className="section">
            <h3>Customer Information</h3>
            <div className="details"><span>Name:</span><span>Mr. Rajesh Kumar</span></div>
            <div className="details"><span>Mobile:</span><span>+91 98765 43210</span></div>
            <div className="details"><span>Email:</span><span>rajesh.kumar@email.com</span></div>
            <div className="details"><span>Booking Date:</span><span>{bookingDate}</span></div>
            <div className="details"><span>Booking Time:</span><span>{bookingTime}</span></div>
          </div>

          <div className="section">
            <h3>Payment Information</h3>
            <div className="details"><span>Service Amount:</span><span>₹2,500</span></div>
            <div className="details"><span>Tax (18%):</span><span>₹450</span></div>
            <div className="details total"><span>Total Amount:</span><span>₹2,950</span></div>
            <div className="details"><span>Payment Method:</span><span>Razorpay</span></div>
            <div className="details"><span>Transaction ID:</span><span>TXN{Date.now().toString().slice(-8)}</span></div>
            <div className="details"><span>Payment Status:</span><span>Successful</span></div>
          </div>

          <div className="qr-section">
            <h3>Booking QR Code</h3>
            <img src={`https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${bookingId}&bgcolor=ffffff&color=000000`} alt="Booking QR Code" />
            <p><strong>Booking ID: {bookingId}</strong></p>
          </div>

          <div className="section">
            <h3>Included Services</h3>
            <ul>
              <li>Meet at designated point</li>
              <li>Basic assistance with directions</li>
              <li>Gate escort service</li>
              <li>Real-time coordination</li>
            </ul>
          </div>

          <div className="section rules">
            <h3>Rules and Regulations</h3>
            
            <h4><strong>Service Guidelines</strong></h4>
            <ul>
              <li>Service is valid only for the booked date and flight</li>
              <li>Customer must arrive at the designated meeting point on time</li>
              <li>Our representative will wait for maximum 30 minutes beyond scheduled time</li>
              <li>Valid photo ID is mandatory for service verification</li>
              <li>Service includes assistance as per the selected package only</li>
            </ul>

            <h4><strong>Cancellation Policy</strong></h4>
            <ul>
              <li>Free cancellation up to 24 hours before service time</li>
              <li>50% refund for cancellations between 4-24 hours</li>
              <li>No refund for cancellations within 4 hours of service</li>
              <li>Flight delays/cancellations: Full refund or rescheduling available</li>
            </ul>

            <h4><strong>Modification Policy</strong></h4>
            <ul>
              <li>Service modifications allowed up to 4 hours before flight time</li>
              <li>Date/time changes subject to availability and price difference</li>
              <li>Upgrade requests can be accommodated based on availability</li>
              <li>Terminal changes must be notified immediately</li>
            </ul>

            <h4><strong>Customer Responsibilities</strong></h4>
            <ul>
              <li>Provide accurate flight and contact information</li>
              <li>Carry valid identification documents</li>
              <li>Inform about any special requirements during booking</li>
              <li>Notify immediately about flight schedule changes</li>
              <li>Follow airport security guidelines and regulations</li>
            </ul>

            <h4><strong>Service Limitations</strong></h4>
            <ul>
              <li>Service does not include fast-track immigration for international flights</li>
              <li>Baggage restrictions as per airline policies apply</li>
              <li>Service may be limited during peak hours or emergencies</li>
              <li>Additional charges for services beyond booked package</li>
              <li>Company not liable for flight delays or cancellations</li>
            </ul>

            <h4><strong>Payment Terms</strong></h4>
            <ul>
              <li>Full payment required at the time of booking</li>
              <li>All prices are inclusive of applicable taxes</li>
              <li>Refunds processed within 5-7 business days</li>
              <li>Payment disputes to be resolved within 30 days</li>
            </ul>

            <h4><strong>Force Majeure</strong></h4>
            <ul>
              <li>Services may be affected by natural disasters, strikes, or government actions</li>
              <li>Full refund available for services cancelled due to force majeure</li>
              <li>Alternative arrangements offered when possible</li>
            </ul>
          </div>

          <div className="section">
            <h3>Important Instructions</h3>
            <ul>
              <li>Our representative will contact you 2 hours before your flight time</li>
              <li>Please keep your mobile phone accessible for coordination</li>
              <li>Arrive at the airport at least 2 hours before domestic flights</li>
              <li>Carry valid ID proof and flight tickets</li>
              <li>For any changes or cancellations, contact us at least 4 hours before service time</li>
            </ul>
          </div>

          <div className="section">
            <h3>Customer Support</h3>
            <div className="details"><span>24/7 Support:</span><span>+91 95000 12345</span></div>
            <div className="details"><span>Email:</span><span>support@example.com</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}
