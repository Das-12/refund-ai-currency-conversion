'use client';

export default function ServicesSection() {
  const services = [
    {
      icon: 'ri-user-smile-line',
      title: 'Personalized Meet & Greet',
      description: 'Warm welcome at curbside with traditional Kerala hospitality'
    },
    {
      icon: 'ri-luggage-cart-line',
      title: 'Full Baggage Handling',
      description: 'Complete assistance with your luggage from check-in to boarding'
    },
    {
      icon: 'ri-speed-line',
      title: 'Fast-Track Support',
      description: 'Skip the queues with our priority processing services'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Security & Immigration Escort',
      description: 'Guided assistance through all security checkpoints'
    },
    {
      icon: 'ri-vip-crown-line',
      title: 'Priority Check-in Guidance',
      description: 'Dedicated support for smooth and quick check-in process'
    },
    {
      icon: 'ri-plane-line',
      title: 'Gate Escort Service',
      description: 'Personal escort to your boarding gate until departure'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-yellow-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            Our Premium Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Every detail crafted for your comfort and convenience
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow border-l-4 border-yellow-500">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mb-6">
                <i className={`${service.icon} text-2xl text-yellow-600`}></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">
                {service.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {service.description}
              </p>
              <div className="mt-6 flex items-center text-green-600">
                <i className="ri-check-line text-xl mr-2"></i>
                <span className="font-semibold">Included</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-white rounded-3xl p-8 md:p-12 shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold text-gray-800 mb-6">
                Why Choose FeelSafe Elite?
              </h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mr-4 mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Kerala's Traditional Hospitality</h4>
                    <p className="text-gray-600">Experience the warmth and care that Kerala is famous for</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mr-4 mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Professional & Trained Staff</h4>
                    <p className="text-gray-600">Our team is expertly trained in airport procedures and customer service</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mr-4 mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">24/7 Availability</h4>
                    <p className="text-gray-600">Round-the-clock service for all your travel needs</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=professional%20airport%20concierge%20staff%20in%20traditional%20kerala%20white%20uniform%20helping%20travelers%2C%20warm%20smile%2C%20coconut%20trees%20background%2C%20modern%20airport%20terminal%2C%20professional%20service%2C%20traditional%20indian%20hospitality%2C%20clean%20bright%20lighting&width=600&height=400&seq=service-staff&orientation=landscape"
                alt="Professional Service"
                className="rounded-2xl shadow-lg object-cover w-full h-80"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}