
'use client';

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import AirportSelection from './AirportSelection';
import ServiceSelection from './ServiceSelection';
import FlightSelection from './FlightSelection';
import UserDetails from './UserDetails';
import BookingSummary from './BookingSummary';
import PaymentSection from './PaymentSection';

export interface BookingData {
  airport: string;
  airportName: string;
  serviceType: 'departure' | 'arrival' | '';
  service: string;
  serviceName: string;
  servicePrice: number;
  terminal: string;
  date: string;
  flight: string;
  flightNumber: string;
  flightTime: string;
  userDetails: {
    title: string;
    firstName: string;
    lastName: string;
    mobile: string;
    email: string;
  };
  paymentMode: string;
}

export default function BookingFlow() {
  const searchParams = useSearchParams();
  const [currentStep, setCurrentStep] = useState(1);
  const [bookingData, setBookingData] = useState<BookingData>({
    airport: '',
    airportName: '',
    serviceType: '',
    service: '',
    serviceName: '',
    servicePrice: 0,
    terminal: '',
    date: '',
    flight: '',
    flightNumber: '',
    flightTime: '',
    userDetails: {
      title: '',
      firstName: '',
      lastName: '',
      mobile: '',
      email: ''
    },
    paymentMode: ''
  });

  // Auto-populate booking data from URL params
  useEffect(() => {
    const serviceId = searchParams.get('service');
    const airportCode = searchParams.get('airport');
    const serviceType = searchParams.get('type');
    const terminal = searchParams.get('terminal');

    if (serviceId) {
      // Service mapping
      const serviceMap = {
        '1': { name: 'Basic Meet & Greet', price: 2500 },
        '2': { name: 'Premium Service', price: 4500 },
        '3': { name: 'FlyLux Elite', price: 7500 },
        '4': { name: 'VIP Lounge Access', price: 3500 },
        '5': { name: 'Fast Track Security', price: 2000 },
        '6': { name: 'Baggage Assistance', price: 1500 },
        '7': { name: 'Wheelchair Assistance', price: 1000 },
        '8': { name: 'Child Care Service', price: 3000 }
      };

      // Airport mapping
      const airportMap = {
        'COK': 'Cochin International Airport',
        'MAA': 'Chennai International Airport',
        'CCJ': 'Calicut International Airport',
        'CNN': 'Kannur International Airport'
      };

      const selectedService = serviceMap[serviceId as keyof typeof serviceMap];
      const selectedAirport = airportMap[airportCode as keyof typeof airportMap];

      if (selectedService && selectedAirport && serviceType && terminal) {
        const updatedData = {
          airport: airportCode || '',
          airportName: selectedAirport,
          serviceType: serviceType as 'departure' | 'arrival',
          service: serviceId === '1' ? 'basic' : serviceId === '2' ? 'premium' : 'elite',
          serviceName: selectedService.name,
          servicePrice: selectedService.price,
          terminal: terminal
        };

        setBookingData(prev => ({ ...prev, ...updatedData }));
        
        // Auto-advance to step 2 (Flight Details)
        setCurrentStep(2);
      }
    }
  }, [searchParams]);

  const steps = [
    { number: 1, title: 'Airport & Service', component: 'airport' },
    { number: 2, title: 'Flight Details', component: 'flight' },
    { number: 3, title: 'Personal Details', component: 'user' },
    { number: 4, title: 'Payment', component: 'payment' }
  ];

  const updateBookingData = (data: Partial<BookingData>) => {
    setBookingData(prev => ({ ...prev, ...data }));
  };

  const nextStep = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <AirportSelection 
                bookingData={bookingData}
                updateBookingData={updateBookingData}
                onNext={nextStep}
              />
              <ServiceSelection 
                bookingData={bookingData}
                updateBookingData={updateBookingData}
                onNext={nextStep}
              />
            </div>
            <div>
              <BookingSummary bookingData={bookingData} />
            </div>
          </div>
        );
      case 2:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <FlightSelection 
                bookingData={bookingData}
                updateBookingData={updateBookingData}
                onNext={nextStep}
                onPrev={prevStep}
              />
            </div>
            <div>
              <BookingSummary bookingData={bookingData} />
            </div>
          </div>
        );
      case 3:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <UserDetails 
                bookingData={bookingData}
                updateBookingData={updateBookingData}
                onNext={nextStep}
                onPrev={prevStep}
              />
            </div>
            <div>
              <BookingSummary bookingData={bookingData} />
            </div>
          </div>
        );
      case 4:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <PaymentSection 
                bookingData={bookingData}
                updateBookingData={updateBookingData}
                onPrev={prevStep}
              />
            </div>
            <div>
              <BookingSummary bookingData={bookingData} />
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-slate-900 mb-4">Book Your Service</h1>
        <p className="text-gray-600 text-lg">Complete your booking in simple steps</p>
      </div>

      <div className="mb-8">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => (
            <div key={step.number} className="flex items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${ 
                step.number <= currentStep 
                  ? 'bg-yellow-500 text-black' 
                  : 'bg-gray-200 text-gray-500'
              }`}>
                {step.number}
              </div>
              <div className="ml-3">
                <div className={`font-medium ${ 
                  step.number <= currentStep ? 'text-slate-900' : 'text-gray-500'
                }`}>
                  {step.title}
                </div>
              </div>
              {index < steps.length - 1 && (
                <div className={`w-12 h-0.5 mx-4 ${ 
                  step.number < currentStep ? 'bg-yellow-500' : 'bg-gray-200'
                }`}></div>
              )}
            </div>
          ))}
        </div>
      </div>

      {renderStepContent()}
    </div>
  );
}
