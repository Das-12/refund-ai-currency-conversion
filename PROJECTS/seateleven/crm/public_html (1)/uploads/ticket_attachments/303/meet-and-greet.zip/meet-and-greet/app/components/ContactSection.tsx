'use client';

export default function ContactSection() {
  return (
    <section className="py-20 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to Experience Premium Service?
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Book your FeelSafe Elite service today and travel with confidence and comfort
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div>
            <h3 className="text-3xl font-bold mb-8">Get in Touch</h3>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-start">
                <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-phone-line text-black text-xl"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-1">24/7 Booking Hotline</h4>
                  <p className="text-gray-300">+91 9876543210</p>
                  <p className="text-gray-400 text-sm">Available round the clock for your convenience</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-mail-line text-black text-xl"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-1">Email Support</h4>
                  <p className="text-gray-300">support@feelsafeelite.com</p>
                  <p className="text-gray-400 text-sm">We respond within 2 hours</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-time-line text-black text-xl"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-1">Service Hours</h4>
                  <p className="text-gray-300">24/7 - All Days</p>
                  <p className="text-gray-400 text-sm">Round the clock airport assistance</p>
                </div>
              </div>
            </div>

            
          </div>

          <div className="bg-gray-800 rounded-2xl p-6 mb-8">
              <h4 className="font-bold text-xl mb-4">Quick Booking Tips</h4>
              <ul className="space-y-2 text-gray-300">
                <li className="flex items-center">
                  <i className="ri-check-line text-green-400 mr-2"></i>
                  Book at least 4 hours before your flight
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-400 mr-2"></i>
                  Provide accurate flight details
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-400 mr-2"></i>
                  Share any special requirements
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-400 mr-2"></i>
                  Keep your phone accessible
                </li>
              </ul>
            </div>
        </div>

        <div className="mt-16 text-center">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <div className="text-3xl font-bold text-yellow-400 mb-2">COK</div>
              <div className="text-gray-300">Cochin</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-yellow-400 mb-2">MAA</div>
              <div className="text-gray-300">Chennai</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-yellow-400 mb-2">CCJ</div>
              <div className="text-gray-300">Calicut</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-yellow-400 mb-2">CNN</div>
              <div className="text-gray-300">Kannur</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}