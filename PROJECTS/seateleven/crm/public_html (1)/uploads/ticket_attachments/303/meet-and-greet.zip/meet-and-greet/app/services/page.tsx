'use client';

import { useState, useMemo } from 'react';
import Link from 'next/link';
import Header from '../components/Header';
import ServiceCard from './ServiceCard';
import FilterSection from './FilterSection';

export interface Service {
  id: string;
  name: string;
  type: 'departure' | 'arrival';
  airport: string;
  airportName: string;
  terminal: string;
  price: number;
  duration: string;
  rating: number;
  reviews: number;
  features: string[];
  description: string;
  image: string;
  category: 'basic' | 'premium' | 'elite';
}

export default function ServicesPage() {
  const [selectedAirport, setSelectedAirport] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [sortBy, setSortBy] = useState('price-low');

  const services: Service[] = [
    {
      id: '1',
      name: 'Basic Meet & Greet',
      type: 'departure',
      airport: 'COK',
      airportName: 'Cochin International Airport',
      terminal: 'Terminal 1',
      price: 2500,
      duration: '30 minutes',
      rating: 4.2,
      reviews: 156,
      features: ['Meet at designated point', 'Basic assistance', 'Gate escort'],
      description: 'Essential assistance for smooth airport experience',
      image: 'https://readdy.ai/api/search-image?query=Professional%20airport%20staff%20greeting%20passenger%20with%20welcome%20sign%20at%20modern%20airport%20terminal%2C%20clean%20bright%20lighting%2C%20friendly%20service%20atmosphere&width=400&height=300&seq=service1&orientation=landscape',
      category: 'basic'
    },
    {
      id: '2',
      name: 'Premium Departure Service',
      type: 'departure',
      airport: 'COK',
      airportName: 'Cochin International Airport',
      terminal: 'Terminal 2',
      price: 4500,
      duration: '45 minutes',
      rating: 4.6,
      reviews: 289,
      features: ['Curbside meet & greet', 'Baggage handling', 'Priority check-in', 'Security escort'],
      description: 'Enhanced departure experience with priority services',
      image: 'https://readdy.ai/api/search-image?query=Luxury%20airport%20concierge%20service%20with%20premium%20baggage%20handling%2C%20elegant%20staff%20uniform%2C%20upscale%20airport%20terminal%20environment&width=400&height=300&seq=service2&orientation=landscape',
      category: 'premium'
    },
    {
      id: '3',
      name: 'Elite Arrival Experience',
      type: 'arrival',
      airport: 'MAA',
      airportName: 'Chennai International Airport',
      terminal: 'International Terminal',
      price: 7500,
      duration: '60 minutes',
      rating: 4.9,
      reviews: 432,
      features: ['Personalized welcome', 'Immigration assistance', 'Baggage collection', 'Transfer coordination'],
      description: 'Ultimate luxury arrival service with complete assistance',
      image: 'https://readdy.ai/api/search-image?query=VIP%20airport%20arrival%20lounge%20with%20luxury%20seating%2C%20professional%20staff%20welcoming%20business%20travelers%2C%20premium%20airport%20interior%20design&width=400&height=300&seq=service3&orientation=landscape',
      category: 'elite'
    },
    {
      id: '4',
      name: 'Basic Arrival Support',
      type: 'arrival',
      airport: 'CCJ',
      airportName: 'Calicut International Airport',
      terminal: 'Terminal 1',
      price: 2200,
      duration: '25 minutes',
      rating: 4.1,
      reviews: 198,
      features: ['Airport pickup', 'Basic guidance', 'Exit assistance'],
      description: 'Simple and effective arrival assistance',
      image: 'https://readdy.ai/api/search-image?query=Airport%20arrival%20area%20with%20helpful%20staff%20assisting%20passengers%20with%20directions%2C%20clean%20modern%20terminal%20with%20clear%20signage&width=400&height=300&seq=service4&orientation=landscape',
      category: 'basic'
    },
    {
      id: '5',
      name: 'Premium Arrival Service',
      type: 'arrival',
      airport: 'CNN',
      airportName: 'Kannur International Airport',
      terminal: 'Terminal 1',
      price: 4200,
      duration: '40 minutes',
      rating: 4.5,
      reviews: 267,
      features: ['Personalized meet & greet', 'Baggage assistance', 'Ground transport coordination'],
      description: 'Comprehensive arrival support with premium touches',
      image: 'https://readdy.ai/api/search-image?query=Premium%20airport%20arrival%20service%20with%20professional%20staff%20helping%20with%20luggage%2C%20modern%20airport%20setting%2C%20customer%20service%20excellence&width=400&height=300&seq=service5&orientation=landscape',
      category: 'premium'
    },
    {
      id: '6',
      name: 'Elite Departure Experience',
      type: 'departure',
      airport: 'MAA',
      airportName: 'Chennai International Airport',
      terminal: 'International Terminal',
      price: 8000,
      duration: '90 minutes',
      rating: 4.8,
      reviews: 356,
      features: ['Curbside luxury service', 'Fast-track security', 'VIP lounge access', 'Boarding assistance'],
      description: 'Premium departure with exclusive VIP treatment',
      image: 'https://readdy.ai/api/search-image?query=VIP%20airport%20departure%20lounge%20with%20luxury%20amenities%2C%20elegant%20staff%20providing%20exclusive%20service%2C%20premium%20airport%20interior&width=400&height=300&seq=service6&orientation=landscape',
      category: 'elite'
    },
    {
      id: '7',
      name: 'Basic Departure Support',
      type: 'departure',
      airport: 'CCJ',
      airportName: 'Calicut International Airport',
      terminal: 'Terminal 1',
      price: 2300,
      duration: '30 minutes',
      rating: 4.0,
      reviews: 142,
      features: ['Check-in assistance', 'Security guidance', 'Gate directions'],
      description: 'Essential departure support for smooth travel',
      image: 'https://readdy.ai/api/search-image?query=Airport%20departure%20area%20with%20staff%20helping%20passengers%20at%20check-in%20counter%2C%20organized%20airport%20environment%2C%20helpful%20service&width=400&height=300&seq=service7&orientation=landscape',
      category: 'basic'
    },
    {
      id: '8',
      name: 'Premium Departure Plus',
      type: 'departure',
      airport: 'CNN',
      airportName: 'Kannur International Airport',
      terminal: 'Terminal 1',
      price: 4800,
      duration: '50 minutes',
      rating: 4.4,
      reviews: 213,
      features: ['Premium check-in', 'Priority security', 'Lounge coordination', 'Boarding escort'],
      description: 'Enhanced departure with premium amenities',
      image: 'https://readdy.ai/api/search-image?query=Premium%20airport%20departure%20service%20with%20staff%20escorting%20passengers%20through%20security%2C%20modern%20terminal%20with%20premium%20service%20areas&width=400&height=300&seq=service8&orientation=landscape',
      category: 'premium'
    }
  ];

  const airports = [
    { code: 'COK', name: 'Cochin International Airport', city: 'Kochi' },
    { code: 'MAA', name: 'Chennai International Airport', city: 'Chennai' },
    { code: 'CCJ', name: 'Calicut International Airport', city: 'Kozhikode' },
    { code: 'CNN', name: 'Kannur International Airport', city: 'Kannur' }
  ];

  const filteredServices = useMemo(() => {
    let filtered = services;

    if (selectedAirport) {
      filtered = filtered.filter(service => service.airport === selectedAirport);
    }

    if (selectedType) {
      filtered = filtered.filter(service => service.type === selectedType);
    }

    if (selectedCategory) {
      filtered = filtered.filter(service => service.category === selectedCategory);
    }

    // Sort services
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        case 'rating':
          return b.rating - a.rating;
        case 'reviews':
          return b.reviews - a.reviews;
        default:
          return 0;
      }
    });

    return filtered;
  }, [services, selectedAirport, selectedType, selectedCategory, sortBy]);

  const clearFilters = () => {
    setSelectedAirport('');
    setSelectedType('');
    setSelectedCategory('');
    setSortBy('price-low');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="pt-20">
        <div className="bg-slate-900 text-white py-16">
          <div className="max-w-7xl mx-auto px-6 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Services</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Discover our comprehensive range of airport assistance services designed to make your journey seamless and comfortable
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            <div className="lg:col-span-1">
              <FilterSection
                airports={airports}
                selectedAirport={selectedAirport}
                setSelectedAirport={setSelectedAirport}
                selectedType={selectedType}
                setSelectedType={setSelectedType}
                selectedCategory={selectedCategory}
                setSelectedCategory={setSelectedCategory}
                sortBy={sortBy}
                setSortBy={setSortBy}
                onClearFilters={clearFilters}
                totalResults={filteredServices.length}
              />
            </div>

            <div className="lg:col-span-3">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-slate-900">
                  Available Services ({filteredServices.length})
                </h2>
                <Link 
                  href="/booking"
                  className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-2 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap"
                >
                  Book Service
                </Link>
              </div>

              {filteredServices.length === 0 ? (
                <div className="text-center py-12">
                  <i className="ri-search-line text-6xl text-gray-400 mb-4"></i>
                  <h3 className="text-xl font-semibold text-gray-600 mb-2">No services found</h3>
                  <p className="text-gray-500 mb-4">Try adjusting your filters to find more services</p>
                  <button
                    onClick={clearFilters}
                    className="bg-gray-800 hover:bg-gray-900 text-white px-6 py-2 rounded-lg cursor-pointer"
                  >
                    Clear All Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {filteredServices.map((service) => (
                    <ServiceCard key={service.id} service={service} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}