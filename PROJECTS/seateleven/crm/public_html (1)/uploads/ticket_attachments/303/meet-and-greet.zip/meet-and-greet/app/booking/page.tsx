
'use client';

import { Suspense } from 'react';
import Header from '../components/Header';
import BookingFlow from './BookingFlow';

function BookingContent() {
  return <BookingFlow />;
}

export default function BookingPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="pt-24">
        <Suspense fallback={
          <div className="flex items-center justify-center min-h-screen">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-500 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading booking form...</p>
            </div>
          </div>
        }>
          <BookingContent />
        </Suspense>
      </div>
    </div>
  );
}
