'use client';

interface FilterSectionProps {
  airports: Array<{ code: string; name: string; city: string }>;
  selectedAirport: string;
  setSelectedAirport: (airport: string) => void;
  selectedType: string;
  setSelectedType: (type: string) => void;
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
  sortBy: string;
  setSortBy: (sort: string) => void;
  onClearFilters: () => void;
  totalResults: number;
}

export default function FilterSection({
  airports,
  selectedAirport,
  setSelectedAirport,
  selectedType,
  setSelectedType,
  selectedCategory,
  setSelectedCategory,
  sortBy,
  setSortBy,
  onClearFilters,
  totalResults
}: FilterSectionProps) {
  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg h-fit sticky top-24">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-slate-900">Filters</h3>
        <button
          onClick={onClearFilters}
          className="text-sm text-gray-600 hover:text-slate-900 cursor-pointer"
        >
          Clear All
        </button>
      </div>

      <div className="space-y-6">
        {/* Airport Filter */}
        <div>
          <h4 className="font-semibold text-slate-900 mb-3">Airport</h4>
          <div className="space-y-2">
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="airport"
                value=""
                checked={selectedAirport === ''}
                onChange={(e) => setSelectedAirport(e.target.value)}
                className="mr-3"
              />
              <span className="text-sm text-gray-700">All Airports</span>
            </label>
            {airports.map((airport) => (
              <label key={airport.code} className="flex items-center cursor-pointer">
                <input
                  type="radio"
                  name="airport"
                  value={airport.code}
                  checked={selectedAirport === airport.code}
                  onChange={(e) => setSelectedAirport(e.target.value)}
                  className="mr-3"
                />
                <div className="flex-1">
                  <div className="text-sm font-medium text-gray-900">{airport.code}</div>
                  <div className="text-xs text-gray-500">{airport.city}</div>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Service Type Filter */}
        <div>
          <h4 className="font-semibold text-slate-900 mb-3">Service Type</h4>
          <div className="space-y-2">
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="type"
                value=""
                checked={selectedType === ''}
                onChange={(e) => setSelectedType(e.target.value)}
                className="mr-3"
              />
              <span className="text-sm text-gray-700">All Types</span>
            </label>
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="type"
                value="departure"
                checked={selectedType === 'departure'}
                onChange={(e) => setSelectedType(e.target.value)}
                className="mr-3"
              />
              <div className="flex items-center">
                <i className="ri-takeoff-line text-blue-500 mr-2"></i>
                <span className="text-sm text-gray-700">Departure</span>
              </div>
            </label>
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="type"
                value="arrival"
                checked={selectedType === 'arrival'}
                onChange={(e) => setSelectedType(e.target.value)}
                className="mr-3"
              />
              <div className="flex items-center">
                <i className="ri-flight-land-line text-green-500 mr-2"></i>
                <span className="text-sm text-gray-700">Arrival</span>
              </div>
            </label>
          </div>
        </div>

        {/* Category Filter */}
        <div>
          <h4 className="font-semibold text-slate-900 mb-3">Service Category</h4>
          <div className="space-y-2">
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="category"
                value=""
                checked={selectedCategory === ''}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="mr-3"
              />
              <span className="text-sm text-gray-700">All Categories</span>
            </label>
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="category"
                value="basic"
                checked={selectedCategory === 'basic'}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="mr-3"
              />
              <div className="flex items-center">
                <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                <span className="text-sm text-gray-700">Basic</span>
              </div>
            </label>
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="category"
                value="premium"
                checked={selectedCategory === 'premium'}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="mr-3"
              />
              <div className="flex items-center">
                <div className="w-3 h-3 bg-purple-500 rounded-full mr-2"></div>
                <span className="text-sm text-gray-700">Premium</span>
              </div>
            </label>
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="category"
                value="elite"
                checked={selectedCategory === 'elite'}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="mr-3"
              />
              <div className="flex items-center">
                <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                <span className="text-sm text-gray-700">Elite</span>
              </div>
            </label>
          </div>
        </div>

        {/* Sort Options */}
        <div>
          <h4 className="font-semibold text-slate-900 mb-3">Sort By</h4>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-500 text-sm pr-8"
          >
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="rating">Highest Rated</option>
            <option value="reviews">Most Reviews</option>
          </select>
        </div>

        {/* Results Count */}
        <div className="pt-4 border-t border-gray-200">
          <div className="text-sm text-gray-600 text-center">
            {totalResults} service{totalResults !== 1 ? 's' : ''} found
          </div>
        </div>
      </div>
    </div>
  );
}