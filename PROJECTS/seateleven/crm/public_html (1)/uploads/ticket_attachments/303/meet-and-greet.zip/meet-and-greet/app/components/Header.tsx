'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-slate-900 text-white fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-3">
            <img 
              src="https://static.readdy.ai/image/2eec6856fa10ad48a621c0c109234386/1d4029bb2034a8d8a627eef1df4f1962.jfif" 
              alt="FlyLux Logo" 
              className="h-12 w-auto"
            />
            <div>
              <h1 className="text-2xl font-bold text-yellow-400">FLYLUX</h1>
              <p className="text-xs text-yellow-300 tracking-wide">LUXURY MEETS ARRIVAL</p>
            </div>
          </Link>

          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="hover:text-yellow-400 transition-colors cursor-pointer">
              Home
            </Link>
            <Link href="/services" className="hover:text-yellow-400 transition-colors cursor-pointer">
              Services
            </Link>
            <Link href="/airports" className="hover:text-yellow-400 transition-colors cursor-pointer">
              Airports
            </Link>
            <Link href="/about" className="hover:text-yellow-400 transition-colors cursor-pointer">
              About
            </Link>
            <Link href="/contact" className="hover:text-yellow-400 transition-colors cursor-pointer">
              Contact
            </Link>
            <Link href="/booking" className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-2 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap">
              Book Now
            </Link>
          </nav>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden w-6 h-6 flex items-center justify-center"
          >
            <i className="ri-menu-line text-xl"></i>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-gray-700">
            <nav className="flex flex-col space-y-4 mt-4">
              <Link href="/" className="hover:text-yellow-400 transition-colors cursor-pointer">
                Home
              </Link>
              <Link href="/services" className="hover:text-yellow-400 transition-colors cursor-pointer">
                Services
              </Link>
              <Link href="/airports" className="hover:text-yellow-400 transition-colors cursor-pointer">
                Airports
              </Link>
              <Link href="/about" className="hover:text-yellow-400 transition-colors cursor-pointer">
                About
              </Link>
              <Link href="/contact" className="hover:text-yellow-400 transition-colors cursor-pointer">
                Contact
              </Link>
              <Link href="/booking" className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-2 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap w-fit">
                Book Now
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}