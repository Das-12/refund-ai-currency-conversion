
'use client';

import { useState } from 'react';
import { BookingData } from './BookingFlow';

interface FlightSelectionProps {
  bookingData: BookingData;
  updateBookingData: (data: Partial<BookingData>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export default function FlightSelection({ bookingData, updateBookingData, onNext, onPrev }: FlightSelectionProps) {
  const [selectedDate, setSelectedDate] = useState(bookingData.date);
  const [manualDateEntry, setManualDateEntry] = useState(false);
  const [manualDate, setManualDate] = useState('');
  const [customDates, setCustomDates] = useState<string[]>([]);
  const [manualEntry, setManualEntry] = useState(false);
  const [manualFlightNumber, setManualFlightNumber] = useState(bookingData.flightNumber);
  const [manualFlightTime, setManualFlightTime] = useState(bookingData.flightTime);

  const mockFlights = [
    {
      flightNumber: 'AI 681',
      airline: 'Air India',
      time: '08:30',
      destination: 'Delhi',
      status: 'On Time'
    },
    {
      flightNumber: 'SG 471',
      airline: 'SpiceJet',
      time: '10:45',
      destination: 'Mumbai',
      status: 'On Time'
    },
    {
      flightNumber: '6E 286',
      airline: 'IndiGo',
      time: '14:20',
      destination: 'Bangalore',
      status: 'Delayed'
    },
    {
      flightNumber: 'AI 541',
      airline: 'Air India',
      time: '16:55',
      destination: 'Chennai',
      status: 'On Time'
    },
    {
      flightNumber: 'UK 139',
      airline: 'Vistara',
      time: '19:30',
      destination: 'Hyderabad',
      status: 'On Time'
    }
  ];

  const handleDateSelect = (date: string) => {
    setSelectedDate(date);
    setManualDateEntry(false);
    updateBookingData({ date });
  };

  const handleManualDateSelect = () => {
    if (manualDate) {
      setSelectedDate(manualDate);
      updateBookingData({ date: manualDate });
      setManualDateEntry(false);

      // Add to custom dates if not already present
      if (!customDates.includes(manualDate)) {
        setCustomDates(prev => [...prev, manualDate]);
      }

      setManualDate('');
    }
  };

  const handleFlightSelect = (flight: any) => {
    updateBookingData({
      flight: `${flight.flightNumber} - ${flight.destination}`,
      flightNumber: flight.flightNumber,
      flightTime: flight.time
    });
    setManualEntry(false);
  };

  const handleManualSubmit = () => {
    if (manualFlightNumber && manualFlightTime) {
      updateBookingData({
        flight: `${manualFlightNumber} - Manual Entry`,
        flightNumber: manualFlightNumber,
        flightTime: manualFlightTime
      });
    }
  };

  const getNextDates = () => {
    const dates = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      dates.push({
        date: date.toISOString().split('T')[0],
        display: date.toLocaleDateString('en-US', { 
          weekday: 'short', 
          month: 'short', 
          day: 'numeric' 
        }),
        isCustom: false
      });
    }

    // Add custom dates
    customDates.forEach(customDate => {
      const date = new Date(customDate);
      dates.push({
        date: customDate,
        display: date.toLocaleDateString('en-US', { 
          weekday: 'short', 
          month: 'short', 
          day: 'numeric' 
        }),
        isCustom: true
      });
    });

    return dates;
  };

  const canProceed = bookingData.date && bookingData.flightNumber && bookingData.flightTime;

  return (
    <div className="bg-white rounded-2xl p-8 shadow-lg">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Flight Details</h2>
        <button
          onClick={onPrev}
          className="text-gray-600 hover:text-slate-900 flex items-center cursor-pointer"
        >
          <i className="ri-arrow-left-line mr-2"></i>
          Back
        </button>
      </div>

      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-slate-900">Select Date</h3>
          <button
            onClick={() => setManualDateEntry(!manualDateEntry)}
            className="text-yellow-600 hover:text-yellow-700 cursor-pointer text-sm"
          >
            {manualDateEntry ? 'Show Date List' : 'Enter Date Manually'}
          </button>
        </div>

        {!manualDateEntry ? (
          <div className="grid grid-cols-3 md:grid-cols-7 gap-3">
            {getNextDates().map((dateObj) => (
              <div
                key={dateObj.date}
                onClick={() => handleDateSelect(dateObj.date)}
                className={`p-4 border-2 rounded-lg cursor-pointer text-center transition-all relative ${
                  selectedDate === dateObj.date
                    ? 'border-yellow-500 bg-yellow-50 text-yellow-700'
                    : 'border-gray-200 hover:border-yellow-300'
                }`}
              >
                <div className="font-medium text-sm">{dateObj.display}</div>
                {dateObj.isCustom && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full"></div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-gray-50 p-6 rounded-lg">
            <h4 className="font-bold text-lg text-slate-900 mb-4">Enter Date Manually</h4>
            <div className="flex items-center space-x-4">
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">Select Date</label>
                <input
                  type="date"
                  value={manualDate}
                  onChange={(e) => setManualDate(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-500 text-sm"
                />
              </div>
              <button
                onClick={handleManualDateSelect}
                className="bg-gray-800 hover:bg-gray-900 text-white px-6 py-3 rounded-lg font-medium cursor-pointer whitespace-nowrap"
              >
                Add Date
              </button>
            </div>
          </div>
        )}
      </div>

      {selectedDate && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-slate-900">
              Available Flights - {bookingData.serviceType === 'departure' ? 'Departures' : 'Arrivals'}
            </h3>
            <button
              onClick={() => setManualEntry(!manualEntry)}
              className="text-yellow-600 hover:text-yellow-700 cursor-pointer"
            >
              {manualEntry ? 'Show Flight List' : 'Enter Manually'}
            </button>
          </div>

          {!manualEntry ? (
            <div className="space-y-3 mb-6">
              {mockFlights.map((flight, index) => (
                <div
                  key={index}
                  onClick={() => handleFlightSelect(flight)}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    bookingData.flightNumber === flight.flightNumber
                      ? 'border-yellow-500 bg-yellow-50'
                      : 'border-gray-200 hover:border-yellow-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div>
                        <div className="font-bold text-lg text-slate-900">{flight.flightNumber}</div>
                        <div className="text-gray-600 text-sm">{flight.airline}</div>
                      </div>
                      <div className="text-center">
                        <div className="font-bold text-xl text-slate-900">{flight.time}</div>
                        <div className="text-gray-600 text-sm">
                          {bookingData.serviceType === 'departure' ? 'To' : 'From'} {flight.destination}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          flight.status === 'On Time' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                        }`}
                      >
                        {flight.status}
                      </div>
                      <i
                        className={`ri-checkbox-circle-${
                          bookingData.flightNumber === flight.flightNumber ? 'fill text-yellow-500' : 'line text-gray-400'
                        } mt-2`}
                      ></i>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-gray-50 p-6 rounded-lg mb-6">
              <h4 className="font-bold text-lg text-slate-900 mb-4">Enter Flight Details Manually</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Flight Number</label>
                  <input
                    type="text"
                    value={manualFlightNumber}
                    onChange={(e) => setManualFlightNumber(e.target.value)}
                    placeholder="e.g., AI 681"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-500 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {bookingData.serviceType === 'departure' ? 'Departure' : 'Arrival'} Time
                  </label>
                  <input
                    type="time"
                    value={manualFlightTime}
                    onChange={(e) => setManualFlightTime(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-500 text-sm"
                  />
                </div>
              </div>
              <button
                onClick={handleManualSubmit}
                className="mt-4 bg-gray-800 hover:bg-gray-900 text-white px-6 py-2 rounded-lg font-medium cursor-pointer whitespace-nowrap"
              >
                Confirm Flight Details
              </button>
            </div>
          )}

          {canProceed && (
            <div className="flex justify-end">
              <button
                onClick={onNext}
                className="bg-yellow-500 hover:bg-yellow-600 text-black px-8 py-3 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap"
              >
                Continue to Personal Details
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
