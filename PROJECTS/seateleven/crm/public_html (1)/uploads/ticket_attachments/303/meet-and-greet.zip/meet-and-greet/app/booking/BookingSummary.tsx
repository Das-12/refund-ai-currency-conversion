
'use client';

import { BookingData } from './BookingFlow';

interface BookingSummaryProps {
  bookingData: BookingData;
}

export default function BookingSummary({ bookingData }: BookingSummaryProps) {
  const taxAmount = Math.round(bookingData.servicePrice * 0.18);
  const totalAmount = bookingData.servicePrice + taxAmount;

  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg sticky top-8">
      <h3 className="text-xl font-bold text-slate-900 mb-6">Booking Summary</h3>
      
      <div className="space-y-4">
        {bookingData.airportName && (
          <div className="flex justify-between items-start">
            <div>
              <div className="font-medium text-gray-900">Airport</div>
              <div className="text-sm text-gray-600">{bookingData.airportName}</div>
            </div>
            <div className="text-right">
              <div className="font-bold text-yellow-600">{bookingData.airport}</div>
            </div>
          </div>
        )}

        {bookingData.serviceType && (
          <div className="flex justify-between items-center">
            <div className="font-medium text-gray-900">Service Type</div>
            <div className="text-sm text-gray-600 capitalize">{bookingData.serviceType}</div>
          </div>
        )}

        {bookingData.serviceName && (
          <div className="border-t pt-4">
            <div className="flex justify-between items-start">
              <div>
                <div className="font-medium text-gray-900">Service</div>
                <div className="text-sm text-gray-600">{bookingData.serviceName}</div>
              </div>
              <div className="text-right">
                <div className="font-bold text-gray-900">₹{bookingData.servicePrice.toLocaleString()}</div>
              </div>
            </div>
          </div>
        )}

        {bookingData.terminal && (
          <div className="flex justify-between items-center">
            <div className="font-medium text-gray-900">Terminal</div>
            <div className="text-sm text-gray-600">{bookingData.terminal}</div>
          </div>
        )}

        {bookingData.date && (
          <div className="flex justify-between items-center">
            <div className="font-medium text-gray-900">Date</div>
            <div className="text-sm text-gray-600">
              {new Date(bookingData.date).toLocaleDateString('en-US', {
                weekday: 'short',
                year: 'numeric',
                month: 'short',
                day: 'numeric'
              })}
            </div>
          </div>
        )}

        {bookingData.flightNumber && (
          <div className="flex justify-between items-start">
            <div>
              <div className="font-medium text-gray-900">Flight</div>
              <div className="text-sm text-gray-600">{bookingData.flightNumber}</div>
            </div>
            <div className="text-right">
              <div className="font-bold text-gray-900">{bookingData.flightTime}</div>
            </div>
          </div>
        )}

        {bookingData.userDetails.firstName && (
          <div className="border-t pt-4">
            <div className="font-medium text-gray-900 mb-2">Passenger Details</div>
            <div className="text-sm text-gray-600">
              {bookingData.userDetails.title} {bookingData.userDetails.firstName} {bookingData.userDetails.lastName}
            </div>
            {bookingData.userDetails.mobile && (
              <div className="text-sm text-gray-600">{bookingData.userDetails.mobile}</div>
            )}
            {bookingData.userDetails.email && (
              <div className="text-sm text-gray-600">{bookingData.userDetails.email}</div>
            )}
          </div>
        )}

        {bookingData.servicePrice > 0 && (
          <div className="border-t pt-4 space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">Service Amount</span>
              <span className="text-gray-900">₹{bookingData.servicePrice.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Tax (18%)</span>
              <span className="text-gray-900">₹{taxAmount.toLocaleString()}</span>
            </div>
            <div className="border-t pt-2">
              <div className="flex justify-between font-bold text-lg">
                <span className="text-gray-900">Total Amount</span>
                <span className="text-yellow-600">₹{totalAmount.toLocaleString()}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {bookingData.servicePrice > 0 && (
        <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <div className="flex items-center text-yellow-800">
            <i className="ri-shield-check-line mr-2"></i>
            <span className="text-sm font-medium">Secure Payment Protected</span>
          </div>
        </div>
      )}
    </div>
  );
}
