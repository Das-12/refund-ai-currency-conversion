
'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const images = [
    {
      url: 'https://wallpapercave.com/wp/wp7797691.jpg',
      title: 'Premium Airport Experience',
      subtitle: 'Your Journey, Our Priority'
    },
    {
      url: 'https://wallpapercave.com/wp/wp6733707.jpg',
      title: 'VIP Lounge Access',
      subtitle: 'Comfort & Luxury Combined'
    },
    {
      url: 'https://wallpapercave.com/wp/wp13811580.jpg',
      title: 'Personal Concierge Service',
      subtitle: 'Excellence in Every Detail'
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % images.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [images.length]);

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat pt-20 overflow-hidden">
      {/* Carousel Background */}
      <div className="absolute inset-0 transition-all duration-1000 ease-in-out">
        {images.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('${image.url}')`
            }}
          />
        ))}
      </div>

      {/* Carousel Indicators */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2 z-10">
        {images.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all cursor-pointer ${
              index === currentSlide ? 'bg-yellow-400' : 'bg-white/50'
            }`}
          />
        ))}
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={() => setCurrentSlide((prev) => (prev - 1 + images.length) % images.length)}
        className="absolute left-6 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white p-3 rounded-full transition-all z-10 cursor-pointer"
      >
        <i className="ri-arrow-left-line text-xl"></i>
      </button>
      
      <button
        onClick={() => setCurrentSlide((prev) => (prev + 1) % images.length)}
        className="absolute right-6 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white p-3 rounded-full transition-all z-10 cursor-pointer"
      >
        <i className="ri-arrow-right-line text-xl"></i>
      </button>

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 text-center text-white">
        <div className="mb-8">
          <h1 className="text-5xl md:text-6xl mb-4 text-yellow-400 font-bold">
            FLYLUX
          </h1>
          <p className="text-xl md:text-2xl mb-2 font-light text-yellow-300">
            LUXURY MEETS ARRIVAL
          </p>
          <p className="text-lg md:text-xl opacity-90">
            Premium Airport Meet & Greet Service in Kerala
          </p>
        </div>

        <div className="mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 transition-all duration-500">
            {images[currentSlide].title}
          </h2>
          <p className="text-lg md:text-xl max-w-4xl mx-auto leading-relaxed transition-all duration-500">
            {images[currentSlide].subtitle} - Experience personalized care with our FlyLux service, designed for travelers who expect comfort, priority, and peace of mind. Our dedicated concierge guides you every step of the way—from the moment you arrive at the curb to your departure at the boarding gate.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/booking" className="bg-yellow-500 hover:bg-yellow-600 text-black px-8 py-4 rounded-full text-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
            Book Service Now
          </Link>
          <Link href="/services" className="border-2 border-white text-white hover:bg-white hover:text-black px-8 py-4 rounded-full text-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
            Learn More
          </Link>
        </div>

        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-3xl font-bold text-yellow-400">4</div>
            <div className="text-sm">Airports</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-3xl font-bold text-yellow-400">24/7</div>
            <div className="text-sm">Service</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-3xl font-bold text-yellow-400">100%</div>
            <div className="text-sm">Satisfaction</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-3xl font-bold text-yellow-400">VIP</div>
            <div className="text-sm">Experience</div>
          </div>
        </div>
      </div>
    </section>
  );
}
