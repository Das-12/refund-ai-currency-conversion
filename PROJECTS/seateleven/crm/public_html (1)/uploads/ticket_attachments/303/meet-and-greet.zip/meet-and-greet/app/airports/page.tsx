'use client';

import { useState } from 'react';
import Link from 'next/link';
import Header from '../components/Header';

interface Terminal {
  id: string;
  name: string;
  type: string;
  services: Service[];
}

interface Service {
  id: string;
  name: string;
  type: 'departure' | 'arrival';
  price: number;
  duration: string;
  rating: number;
  reviews: number;
  features: string[];
  category: 'basic' | 'premium' | 'elite';
}

interface Airport {
  code: string;
  name: string;
  city: string;
  image: string;
  description: string;
  terminals: Terminal[];
}

export default function AirportsPage() {
  const [selectedAirport, setSelectedAirport] = useState<string | null>(null);
  const [selectedTerminal, setSelectedTerminal] = useState<string | null>(null);

  const airports: Airport[] = [
    {
      code: 'COK',
      name: 'Cochin International Airport',
      city: 'Kochi',
      image: 'https://readdy.ai/api/search-image?query=cochin%20international%20airport%20terminal%20building%20with%20kerala%20architecture%2C%20modern%20glass%20structure%2C%20coconut%20trees%2C%20clean%20professional%20environment%2C%20travelers%20with%20luggage%2C%20bright%20natural%20lighting%2C%20contemporary%20design&width=800&height=400&seq=airport-cok-main&orientation=landscape',
      description: 'Major international gateway to Kerala with solar-powered operations and modern facilities.',
      terminals: [
        {
          id: 'terminal-1',
          name: 'Terminal 1',
          type: 'Domestic',
          services: [
            {
              id: 'cok-t1-basic-dep',
              name: 'Basic Meet & Greet',
              type: 'departure',
              price: 2500,
              duration: '30 minutes',
              rating: 4.2,
              reviews: 156,
              features: ['Meet at designated point', 'Basic assistance', 'Gate escort'],
              category: 'basic'
            },
            {
              id: 'cok-t1-premium-dep',
              name: 'Premium Departure Service',
              type: 'departure',
              price: 4500,
              duration: '45 minutes',
              rating: 4.6,
              reviews: 289,
              features: ['Curbside meet & greet', 'Baggage handling', 'Priority check-in', 'Security escort'],
              category: 'premium'
            },
            {
              id: 'cok-t1-basic-arr',
              name: 'Basic Arrival Support',
              type: 'arrival',
              price: 2200,
              duration: '25 minutes',
              rating: 4.1,
              reviews: 198,
              features: ['Airport pickup', 'Basic guidance', 'Exit assistance'],
              category: 'basic'
            }
          ]
        },
        {
          id: 'terminal-2',
          name: 'Terminal 2',
          type: 'Domestic',
          services: [
            {
              id: 'cok-t2-premium-dep',
              name: 'Premium Departure Plus',
              type: 'departure',
              price: 4800,
              duration: '50 minutes',
              rating: 4.4,
              reviews: 213,
              features: ['Premium check-in', 'Priority security', 'Lounge coordination', 'Boarding escort'],
              category: 'premium'
            },
            {
              id: 'cok-t2-elite-dep',
              name: 'Elite Departure Experience',
              type: 'departure',
              price: 7500,
              duration: '90 minutes',
              rating: 4.9,
              reviews: 356,
              features: ['VIP curbside service', 'Fast-track security', 'Premium lounge access', 'Dedicated escort'],
              category: 'elite'
            }
          ]
        },
        {
          id: 'international-terminal',
          name: 'International Terminal',
          type: 'International',
          services: [
            {
              id: 'cok-int-elite-arr',
              name: 'Elite Arrival Experience',
              type: 'arrival',
              price: 8000,
              duration: '60 minutes',
              rating: 4.9,
              reviews: 432,
              features: ['Personalized welcome', 'Immigration assistance', 'Baggage collection', 'Transfer coordination'],
              category: 'elite'
            },
            {
              id: 'cok-int-premium-arr',
              name: 'Premium Arrival Service',
              type: 'arrival',
              price: 4200,
              duration: '40 minutes',
              rating: 4.5,
              reviews: 267,
              features: ['Personalized meet & greet', 'Baggage assistance', 'Ground transport coordination'],
              category: 'premium'
            }
          ]
        }
      ]
    },
    {
      code: 'MAA',
      name: 'Chennai International Airport',
      city: 'Chennai',
      image: 'https://readdy.ai/api/search-image?query=chennai%20international%20airport%20modern%20terminal%20with%20south%20indian%20architectural%20elements%2C%20glass%20facade%2C%20palm%20trees%2C%20professional%20airport%20environment%2C%20clean%20contemporary%20design%2C%20travelers%20and%20staff&width=800&height=400&seq=airport-maa-main&orientation=landscape',
      description: 'Southern India\'s major aviation hub with world-class facilities and connectivity.',
      terminals: [
        {
          id: 'terminal-1',
          name: 'Terminal 1',
          type: 'Domestic',
          services: [
            {
              id: 'maa-t1-basic-dep',
              name: 'Basic Departure Support',
              type: 'departure',
              price: 2300,
              duration: '30 minutes',
              rating: 4.0,
              reviews: 142,
              features: ['Check-in assistance', 'Security guidance', 'Gate directions'],
              category: 'basic'
            },
            {
              id: 'maa-t1-premium-dep',
              name: 'Premium Departure Service',
              type: 'departure',
              price: 4600,
              duration: '45 minutes',
              rating: 4.5,
              reviews: 324,
              features: ['Curbside assistance', 'Priority check-in', 'Security escort', 'Lounge access'],
              category: 'premium'
            }
          ]
        },
        {
          id: 'international-terminal',
          name: 'International Terminal',
          type: 'International',
          services: [
            {
              id: 'maa-int-elite-dep',
              name: 'Elite Departure Experience',
              type: 'departure',
              price: 8500,
              duration: '90 minutes',
              rating: 4.8,
              reviews: 456,
              features: ['VIP curbside service', 'Fast-track immigration', 'Premium lounge access', 'Boarding assistance'],
              category: 'elite'
            },
            {
              id: 'maa-int-elite-arr',
              name: 'Elite Arrival Experience',
              type: 'arrival',
              price: 7800,
              duration: '75 minutes',
              rating: 4.7,
              reviews: 389,
              features: ['Immigration fast-track', 'Baggage collection', 'Customs assistance', 'Transfer coordination'],
              category: 'elite'
            }
          ]
        }
      ]
    },
    {
      code: 'CCJ',
      name: 'Calicut International Airport',
      city: 'Kozhikode',
      image: 'https://readdy.ai/api/search-image?query=calicut%20kozhikode%20airport%20terminal%20building%20with%20kerala%20traditional%20architecture%20mixed%20with%20modern%20elements%2C%20tropical%20landscaping%2C%20coconut%20palms%2C%20clean%20airport%20environment%2C%20professional%20setting&width=800&height=400&seq=airport-ccj-main&orientation=landscape',
      description: 'Regional hub serving North Kerala with excellent Gulf connections and cargo facilities.',
      terminals: [
        {
          id: 'terminal-1',
          name: 'Terminal 1',
          type: 'Domestic & International',
          services: [
            {
              id: 'ccj-t1-basic-dep',
              name: 'Basic Departure Support',
              type: 'departure',
              price: 2100,
              duration: '30 minutes',
              rating: 4.1,
              reviews: 167,
              features: ['Check-in assistance', 'Security guidance', 'Gate directions'],
              category: 'basic'
            },
            {
              id: 'ccj-t1-basic-arr',
              name: 'Basic Arrival Support',
              type: 'arrival',
              price: 2000,
              duration: '25 minutes',
              rating: 4.0,
              reviews: 134,
              features: ['Airport pickup', 'Basic guidance', 'Exit assistance'],
              category: 'basic'
            },
            {
              id: 'ccj-t1-premium-arr',
              name: 'Premium Arrival Service',
              type: 'arrival',
              price: 4000,
              duration: '40 minutes',
              rating: 4.4,
              reviews: 223,
              features: ['Personalized meet & greet', 'Baggage assistance', 'Ground transport coordination'],
              category: 'premium'
            }
          ]
        }
      ]
    },
    {
      code: 'CNN',
      name: 'Kannur International Airport',
      city: 'Kannur',
      image: 'https://readdy.ai/api/search-image?query=kannur%20international%20airport%20modern%20terminal%20with%20kerala%20architectural%20influences%2C%20lush%20green%20surroundings%2C%20contemporary%20glass%20design%2C%20tropical%20vegetation%2C%20professional%20airport%20setting%2C%20clean%20bright%20environment&width=800&height=400&seq=airport-cnn-main&orientation=landscape',
      description: 'Kerala\'s newest international airport with green technology and modern infrastructure.',
      terminals: [
        {
          id: 'terminal-1',
          name: 'Terminal 1',
          type: 'Domestic & International',
          services: [
            {
              id: 'cnn-t1-basic-dep',
              name: 'Basic Meet & Greet',
              type: 'departure',
              price: 2200,
              duration: '30 minutes',
              rating: 4.2,
              reviews: 145,
              features: ['Meet at designated point', 'Basic assistance', 'Gate escort'],
              category: 'basic'
            },
            {
              id: 'cnn-t1-premium-dep',
              name: 'Premium Departure Service',
              type: 'departure',
              price: 4300,
              duration: '45 minutes',
              rating: 4.5,
              reviews: 198,
              features: ['Curbside meet & greet', 'Baggage handling', 'Priority check-in', 'Security escort'],
              category: 'premium'
            },
            {
              id: 'cnn-t1-premium-arr',
              name: 'Premium Arrival Service',
              type: 'arrival',
              price: 4100,
              duration: '40 minutes',
              rating: 4.3,
              reviews: 176,
              features: ['Personalized meet & greet', 'Baggage assistance', 'Ground transport coordination'],
              category: 'premium'
            }
          ]
        }
      ]
    }
  ];

  const selectedAirportData = airports.find(airport => airport.code === selectedAirport);
  const selectedTerminalData = selectedAirportData?.terminals.find(terminal => terminal.id === selectedTerminal);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'basic':
        return 'bg-blue-100 text-blue-800';
      case 'premium':
        return 'bg-purple-100 text-purple-800';
      case 'elite':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'basic':
        return 'ri-star-line';
      case 'premium':
        return 'ri-vip-crown-line';
      case 'elite':
        return 'ri-vip-diamond-line';
      default:
        return 'ri-service-line';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="pt-20">
        <div className="bg-slate-900 text-white py-16">
          <div className="max-w-7xl mx-auto px-6 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Airport Terminals & Services</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Explore our services available at each terminal across major airports
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-6 py-8">
          {!selectedAirport ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {airports.map((airport) => (
                <div key={airport.code} className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                  <div className="relative h-64">
                    <img 
                      src={airport.image}
                      alt={airport.name}
                      className="w-full h-full object-cover object-top"
                    />
                    <div className="absolute top-4 right-4 bg-yellow-500 text-black px-4 py-2 rounded-full font-bold text-lg">
                      {airport.code}
                    </div>
                  </div>
                  <div className="p-8">
                    <h2 className="text-2xl font-bold text-gray-800 mb-2">{airport.name}</h2>
                    <p className="text-gray-600 mb-4 flex items-center">
                      <i className="ri-map-pin-line mr-2"></i>
                      {airport.city}
                    </p>
                    <p className="text-gray-600 mb-6">{airport.description}</p>
                    
                    <div className="mb-6">
                      <div className="flex items-center mb-3">
                        <i className="ri-building-line text-yellow-600 mr-2"></i>
                        <span className="font-semibold text-gray-800">{airport.terminals.length} Terminal{airport.terminals.length > 1 ? 's' : ''}</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {airport.terminals.map((terminal) => (
                          <span key={terminal.id} className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm">
                            {terminal.name} ({terminal.type})
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <button
                        onClick={() => setSelectedAirport(airport.code)}
                        className="w-full bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-3 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap"
                      >
                        View Terminals & Services
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : !selectedTerminal ? (
            <div>
              <div className="mb-8">
                <button
                  onClick={() => setSelectedAirport(null)}
                  className="flex items-center text-gray-600 hover:text-gray-800 mb-4"
                >
                  <i className="ri-arrow-left-line mr-2"></i>
                  Back to Airports
                </button>
                <h2 className="text-3xl font-bold text-gray-800 mb-2">{selectedAirportData?.name}</h2>
                <p className="text-gray-600 text-lg">{selectedAirportData?.description}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {selectedAirportData?.terminals.map((terminal) => (
                  <div key={terminal.id} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xl font-bold text-gray-800">{terminal.name}</h3>
                      <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                        {terminal.type}
                      </span>
                    </div>
                    
                    <div className="mb-6">
                      <div className="flex items-center mb-3">
                        <i className="ri-service-line text-yellow-600 mr-2"></i>
                        <span className="font-semibold text-gray-800">{terminal.services.length} Services Available</span>
                      </div>
                      <div className="space-y-2">
                        {terminal.services.map((service) => (
                          <div key={service.id} className="flex items-center justify-between text-sm">
                            <span className="text-gray-600">{service.name}</span>
                            <span className="font-semibold text-gray-800">₹{service.price.toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={() => setSelectedTerminal(terminal.id)}
                      className="w-full bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-3 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap"
                    >
                      View Services
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div>
              <div className="mb-8">
                <button
                  onClick={() => setSelectedTerminal(null)}
                  className="flex items-center text-gray-600 hover:text-gray-800 mb-4"
                >
                  <i className="ri-arrow-left-line mr-2"></i>
                  Back to Terminals
                </button>
                <div className="flex items-center gap-4 mb-4">
                  <h2 className="text-3xl font-bold text-gray-800">{selectedTerminalData?.name}</h2>
                  <span className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full font-medium">
                    {selectedTerminalData?.type}
                  </span>
                </div>
                <p className="text-gray-600 text-lg">{selectedAirportData?.name} - {selectedAirportData?.city}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {selectedTerminalData?.services.map((service) => (
                  <div key={service.id} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-gray-800 mb-2">{service.name}</h3>
                        <div className="flex items-center gap-3 mb-2">
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getCategoryColor(service.category)}`}>
                            <i className={`${getCategoryIcon(service.category)} mr-1`}></i>
                            {service.category.charAt(0).toUpperCase() + service.category.slice(1)}
                          </span>
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                            service.type === 'departure' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                          }`}>
                            <i className={`${service.type === 'departure' ? 'ri-flight-takeoff-line' : 'ri-flight-land-line'} mr-1`}></i>
                            {service.type.charAt(0).toUpperCase() + service.type.slice(1)}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-yellow-600">₹{service.price.toLocaleString()}</div>
                        <div className="text-sm text-gray-600">{service.duration}</div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="flex items-center mb-2">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <i key={i} className={`ri-star-${i < Math.floor(service.rating) ? 'fill' : 'line'} text-yellow-500 text-sm`}></i>
                          ))}
                          <span className="ml-2 text-sm text-gray-600">{service.rating} ({service.reviews} reviews)</span>
                        </div>
                      </div>
                    </div>

                    <div className="mb-6">
                      <h4 className="font-semibold text-gray-800 mb-2">Service Features:</h4>
                      <div className="space-y-1">
                        {service.features.map((feature, index) => (
                          <div key={index} className="flex items-center text-sm text-gray-700">
                            <i className="ri-check-line text-green-500 mr-2"></i>
                            {feature}
                          </div>
                        ))}
                      </div>
                    </div>

                    <Link
                      href="/booking"
                      className="w-full bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-3 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap text-center block"
                    >
                      Book This Service
                    </Link>
                  </div>
                ))}
              </div>

              <div className="mt-12 bg-gradient-to-r from-slate-900 to-slate-800 rounded-3xl p-8 text-white text-center">
                <h3 className="text-2xl font-bold mb-4 text-yellow-400">Need Help Choosing?</h3>
                <p className="text-lg mb-6 opacity-90">Our customer service team is available 24/7 to help you select the perfect service for your needs.</p>
                <div className="flex items-center justify-center gap-6">
                  <div className="flex items-center">
                    <i className="ri-phone-line text-yellow-400 mr-2"></i>
                    <span>+91 80000 12345</span>
                  </div>
                  <div className="flex items-center">
                    <i className="ri-mail-line text-yellow-400 mr-2"></i>
                    <span>help@flylux.com</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}